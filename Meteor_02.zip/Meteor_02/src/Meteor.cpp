//
//  Meteor.cpp
//  Meteor_02
//
//  Created by Susse Sønderby Jensen on 10/20/13.
//
//

#include "Meteor.h"


// --------------------------------------
void Meteor::init() {
        position.x = ofRandomWidth(); // ofRandom(0, ofGetWidth());
        position.y = ofRandomHeight();
    
        size = 5;
        speedx = ofRandom(-1, 1);
        speedy = ofRandom(-1, 1);
    
        
    exploded = false;
}

// --------------------------------------
void Meteor::update(vector<Star>& stars) {
    
    if (position.x >= ofGetWidth()-size) {
        speedx *= -1;
        
        //size += .1;
        //bMeteorSize = true;
    }
    else if (position.x < size){
        speedx *= -1;
    }
    else if (position.y > ofGetHeight()-size) {
        speedy *= -1;
        //bMeteorSize = true;
    }
    else if (position.y < size) {
        speedy *= -1;
        //bMeteorSize = true;
    }

    position.x += speedx;
    position.y += speedy;
    //speedx += size;
    
    
    for(int i=0; i<stars.size(); i++) {
        float d = ofDist(position.x, position.y, stars[i].xpos, stars[i].ypos);
        if(d < size) {
            size += 5;
        }
    }
    
    
    
    if(size > 50) {
        exploded = true;
    }
    
}
// --------------------------------------

// --------------------------------------
void Meteor::draw() {
    
    if(!exploded)
    {
        ofSetColor(255, ofRandom(0,255), 0);
        ofCircle(position, size);
        

    }
    else {
        // draw exploded cow
    }
    
    
}


